package simulator.model;

public class Alimentation {

	public enum Diet{HERBIVORE, CARNIVORE};
	
}
