package simulator.model;

public interface Entity {

	public void update(double dt);
	
}
